package com.example.lab7_retrofit.networking.response.categories

data class categoriesResponse(val categories: List<categories>)
