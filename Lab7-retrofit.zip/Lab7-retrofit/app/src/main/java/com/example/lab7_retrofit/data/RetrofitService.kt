package com.example.lab7_retrofit.data

interface RetrofitService {

}